#include "nim.h"
#include <stdio.h>
#include <stdlib.h>

int *new_board(int board_size)
{
    int *array = malloc(sizeof(int) * board_size);
    if (array == NULL)
    {
        fprintf(stderr, "Error in new_board");
        exit(1);
    }
    return array;
}

struct node *mk_nim_hash(int max_hash, int board_size, int *start_board)
{
    struct node *array = malloc(sizeof(struct node) * max_hash);
    if (array == NULL)
    {
        fprintf(stderr, "Error in m_nim_hash");
        exit(1);
    }
    for (int i = 0; i < max_hash; i++)
    {
        array[i].moves = -1;
        array[i].move = NULL;
        array[i].nimsum = -1;
        array[i].board = hash2board(board_size, start_board, i);
    }
    return array;
}

void free_board(int *board)
{
    free(board);
}

void free_nim_hash(int max_hash, struct node *nim_hash)
{
    for (int i = 0; i < max_hash; i++)
    {
        free(nim_hash[i].board);
        free(nim_hash[i].move);
    }
    free(nim_hash);
}

// other functions for students to write
int *board_from_argv(int board_size, char **argv)
{
    int *board = new_board(board_size);
    for (int i = 0; i < board_size; i++)
    {
        board[i] = atoi(argv[i]);
    }
    return board;
}
int *copy_board(int board_size, int *board)
{
    int *copy = new_board(board_size);
    for (int i = 0; i < board_size; i++)
    {
        copy[i] = board[i];
    }
    return copy;
}

int game_over(int board_size, int *board)
{
    int matches = 0;
    for (int i = 0; i < board_size; i++)
    {
        matches += board[i];
    }
    return matches == 1 ? 1 : 0;
}
void join_graph(struct node *nim_hash, int hash, int board_size,
                int *start_board)
{
    if (nim_hash[hash].moves != -1)
        return;

    int totalMoves = 0;
    for (int i = 0; i < board_size; i++)
    {
        totalMoves += nim_hash[hash].board[i];
    }
    nim_hash[hash].moves = totalMoves;
    nim_hash[hash].move = malloc(sizeof(struct move) * totalMoves);
    int thisMove = 0;

    for (int row = 0; row < board_size; row++)
    {
        for (int matches = 1; matches <= nim_hash[hash].board[row]; matches++)
        {
            nim_hash[hash].move[thisMove].row = row;
            nim_hash[hash].move[thisMove].matches = matches;
            int *current_board = copy_board(board_size, nim_hash[hash].board);
            current_board[row] -= matches;
            int newHash = board2hash(board_size, start_board, current_board);
            nim_hash[hash].move[thisMove].hash = newHash;
            nim_hash[newHash].nimsum=compute_numsum(board_size,nim_hash[newHash].board);
            thisMove++;
            join_graph(nim_hash, newHash, board_size, start_board);
            free(current_board);
        }
    }
}

int compute_numsum(int board_size, int *board)
{
    int nimsum = board[0];
    int check = nimsum > 1 ? 1:0;

    for(int i=1;i<board_size;i++){
        nimsum = nimsum ^ board[i];
        if(board[i]>1){
            check =1;
        }
    }
    nimsum = check==1?nimsum:nimsum*-1;
    return nimsum;
}
